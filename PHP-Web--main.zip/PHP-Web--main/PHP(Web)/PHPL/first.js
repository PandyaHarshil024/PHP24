var a=7;
var b=5;
var c=a+b;
document.writeln("sum is ",c);